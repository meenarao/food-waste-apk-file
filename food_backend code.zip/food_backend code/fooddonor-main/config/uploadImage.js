const express = require("express");
const cloudinary = require("cloudinary").v2;
const multer = require("multer");
const { CloudinaryStorage } = require("multer-storage-cloudinary");
const app = express();



          
cloudinary.config({ 
  cloud_name: 'ddyvmajji', 
  api_key: '342651775965525', 
  api_secret: 'JMQRIThb8iL4Sl5_5ocQm-CKQDY' ,
  secure: true,
});
// Create a multer storage object for Cloudinary
const storage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: {
    folder: "images",
    allowed_formats: ["jpg", "jpeg", "png"],
    transformation: [{ width: 500, height: 500, crop: "limit" }],
  },
});

// Create a multer instance with the storage configuration
const upload = multer({ storage: storage });

// Route to handle image upload
app.post("/", upload.single("image"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "No image uploaded" });
  }
  const imageUrl = req.file.path;
  res.status(200).send({ imageUrl: imageUrl });
});

module.exports = app;
